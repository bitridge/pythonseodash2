#!/usr/bin/env python3
import os
import sys
import subprocess
import getpass
import secrets
import string
from pathlib import Path

class SetupWizard:
    def __init__(self):
        self.project_dir = Path(__file__).resolve().parent
        self.env_file = self.project_dir / '.env'
        self.venv_dir = self.project_dir / 'venv'
        self.requirements_file = self.project_dir / 'requirements.txt'

    def print_welcome(self):
        print("\n=== SEO Dashboard Installation Wizard ===")
        print("This wizard will help you set up the SEO Dashboard application.")
        print("Make sure you have Python 3.8+ and pip installed.\n")

    def check_python_version(self):
        if sys.version_info < (3, 8):
            print("Error: Python 3.8 or higher is required.")
            sys.exit(1)

    def create_virtual_environment(self):
        print("\nCreating virtual environment...")
        if not self.venv_dir.exists():
            subprocess.run([sys.executable, '-m', 'venv', 'venv'])
        
        # Get the correct pip and python paths
        if os.name == 'nt':  # Windows
            self.pip_path = self.venv_dir / 'Scripts' / 'pip'
            self.python_path = self.venv_dir / 'Scripts' / 'python'
        else:  # Unix/Linux
            self.pip_path = self.venv_dir / 'bin' / 'pip'
            self.python_path = self.venv_dir / 'bin' / 'python'

    def install_requirements(self):
        print("\nInstalling required packages...")
        subprocess.run([str(self.pip_path), 'install', '-r', str(self.requirements_file)])

    def generate_secret_key(self):
        alphabet = string.ascii_letters + string.digits + string.punctuation
        return ''.join(secrets.choice(alphabet) for _ in range(50))

    def get_database_credentials(self):
        print("\n=== Database Configuration ===")
        print("Please enter your database credentials:")
        
        db_config = {
            'ENGINE': input("Database engine (1: PostgreSQL, 2: MySQL) [2]: ") or "2",
            'NAME': input("Database name: "),
            'USER': input("Database user: "),
            'PASSWORD': getpass.getpass("Database password: "),
            'HOST': input("Database host [localhost]: ") or "localhost",
            'PORT': input("Database port [3306]: ") or "3306"
        }
        
        # Convert engine choice to actual engine setting
        db_config['ENGINE'] = {
            "1": "django.db.backends.postgresql",
            "2": "django.db.backends.mysql"
        }.get(db_config['ENGINE'], "django.db.backends.mysql")
        
        return db_config

    def create_env_file(self, db_config):
        print("\nCreating environment file...")
        secret_key = self.generate_secret_key()
        
        env_content = f"""# Django Settings
DJANGO_SETTINGS_MODULE=seo_dashboard.settings
DJANGO_SECRET_KEY='{secret_key}'
DJANGO_DEBUG=False

# Database Settings
DB_ENGINE={db_config['ENGINE']}
DB_NAME={db_config['NAME']}
DB_USER={db_config['USER']}
DB_PASSWORD={db_config['PASSWORD']}
DB_HOST={db_config['HOST']}
DB_PORT={db_config['PORT']}

# Email Settings (configure these later)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=
EMAIL_HOST_PASSWORD=

# Security Settings
ALLOWED_HOSTS=.localhost,127.0.0.1,[your-domain-here]
CSRF_TRUSTED_ORIGINS=https://[your-domain-here]
"""
        
        with open(self.env_file, 'w') as f:
            f.write(env_content)

    def setup_database(self):
        print("\nSetting up database...")
        subprocess.run([str(self.python_path), 'manage.py', 'migrate'])

    def create_superuser(self):
        print("\nCreating superuser account...")
        subprocess.run([str(self.python_path), 'manage.py', 'createsuperuser'])

    def collect_static(self):
        print("\nCollecting static files...")
        subprocess.run([str(self.python_path), 'manage.py', 'collectstatic', '--noinput'])

    def setup_permissions(self):
        print("\nSetting up file permissions...")
        if os.name != 'nt':  # Skip on Windows
            subprocess.run(['chmod', '-R', '755', str(self.project_dir)])
            media_dir = self.project_dir / 'media'
            static_dir = self.project_dir / 'staticfiles'
            
            # Create directories if they don't exist
            media_dir.mkdir(exist_ok=True)
            static_dir.mkdir(exist_ok=True)
            
            # Set permissions
            subprocess.run(['chmod', '-R', '775', str(media_dir)])
            subprocess.run(['chmod', '-R', '775', str(static_dir)])

    def print_completion(self):
        print("\n=== Installation Complete ===")
        print("The SEO Dashboard has been successfully installed!")
        print("\nNext steps:")
        print("1. Configure your web server (Nginx/Apache)")
        print("2. Set up SSL certificate")
        print("3. Update ALLOWED_HOSTS in .env file")
        print("4. Configure email settings in .env file")
        print("\nTo start the development server:")
        print(f"cd {self.project_dir}")
        print("source venv/bin/activate  # On Unix/Linux")
        print("python manage.py runserver")

    def run(self):
        try:
            self.print_welcome()
            self.check_python_version()
            self.create_virtual_environment()
            self.install_requirements()
            db_config = self.get_database_credentials()
            self.create_env_file(db_config)
            self.setup_database()
            self.create_superuser()
            self.collect_static()
            self.setup_permissions()
            self.print_completion()
        except KeyboardInterrupt:
            print("\nInstallation cancelled by user.")
            sys.exit(1)
        except Exception as e:
            print(f"\nError during installation: {e}")
            sys.exit(1)

if __name__ == "__main__":
    wizard = SetupWizard()
    wizard.run() 